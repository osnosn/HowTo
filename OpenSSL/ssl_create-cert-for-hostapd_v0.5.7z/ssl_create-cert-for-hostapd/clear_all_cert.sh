#!/bin/sh
# ./clear_all_cert.sh

if [  "$#" -ne 1  -o  "$1" != "clearall" ]; then
   echo "Usage: $0 clearall"
   echo "     Clear all the \"keys\" and \"certs\"."
   echo "     It will remove *.pem"
   echo "     It will remove 3certs_new/* 4export/* user_certs/*"
   echo "     It will remove ALL!!!!!"
   exit 1
fi

if [ -f ca_key.pem ]; then
   rm -f ca_key.pem ca_cert.pem ca_cert.txt
fi
if [ -f crl.pem ]; then
   rm -f crl.pem ca_cert+crl.pem
fi
if [ -f server_key.pem ]; then
   rm -f server_key.pem server_cert.pem
fi
if [ -d user_certs ]; then
   rm -f user_certs/*
fi
if [ -d 3certs_new ]; then
   rm -f 3certs_new/*
fi
if [ -d 4export ]; then
   rm -f 4export/*
fi
if [ -f 2db/0serial ]; then
   rm -f 2db/0serial.old
fi
if [ -f 2db/2indexdb.txt ]; then
   cat /dev/null > 2db/2indexdb.txt
   rm -f 2db/2indexdb.txt.attr 2db/2indexdb.txt.attr.old 2db/2indexdb.txt.old
fi
echo "  ALL cert files removed."
echo "You may now run ./new-ca.sh to get start"
echo ""
