#!/bin/sh
# ./copy-pem-to.sh

DIR=$1
if [  "$#" -ne 1  -o  "${#DIR}" -le "1" ]; then
        echo "Usage: $0 dest_directory"
        echo "     $0  ./"
        echo "     $0  a/"
        exit 1
fi
if [ ! -d $DIR ]; then
	echo " \"$DIR\" directory not found. Exit."
	exit 1
fi

echo "copy \"ca_cert+crl.pem\" \"server_cert.pem\" \"server_key.pem\" to \"$DIR\""
cp -i ca_cert+crl.pem $DIR
cp -i server_cert.pem $DIR
cp -i server_key.pem  $DIR

