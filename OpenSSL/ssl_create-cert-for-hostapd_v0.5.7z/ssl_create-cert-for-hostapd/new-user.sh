#!/bin/sh

#./new-user.sh
# Create the user key and cert. This should be done once per cert.
if [ $# -lt 3 ]; then
   echo
   echo "Usage: $0  {rsa1024|rsa2048|rsa4096|ec256|ec384}  userName  days [pass]"
   echo "   days between 2 and 365"
   echo
   exit 1
fi
CERT=$2
if [ -f user_certs/user_${CERT}_key.pem ]; then
	echo "user_certs/user_${CERT}_key.pem found. Exit."
	exit 0
fi
keytype=""
case "$1" in
   "rsa1024")
      keytype="rsa:1024"
      ;;
   "rsa2048")
      keytype="rsa:2048"
      ;;
   "rsa4096")
      keytype="rsa:4096"
      ;;
   "ec256")
      keytype="ec:ec_param"
      openssl ecparam -name prime256v1 -out ec_param
      ;;
   "ec384")
      keytype="ec:ec_param"
      openssl ecparam -name secp384r1 -out ec_param
      ;;
   *)
      echo
      echo "Usage: $0  {rsa1024|rsa2048|rsa4096|ec256|ec384}  userName  days [pass]"
      echo "   days between 2 and 365"
      echo
      exit
      ;;
esac

DAYS=${3:-1}  # default 1
if [ "${DAYS}" -gt 365 -o "${DAYS}" -lt 2 ]; then
   if [ "${DAYS}" -ne 36500 ];then
      echo
      echo "Usage: $0  {rsa1024|rsa2048|rsa4096|ec256|ec384}  userName  days [pass]"
      echo "   days between 2 and 365"
      echo
      exit 1
   fi
fi

PASS=${4:-123}  # default 123

exportdir="4export"

export RANDFILE=2db/.random_state
## win10连接EAP-TLS时强制使用用户证书的"CN="作为用户名。建议"CN="不要包含空格。
## freeradius3不允许用户名中包含空格。用hostapd做radius时用户名无此限制。
openssl req -nodes -new -newkey ${keytype} -keyout user_certs/user_${CERT}_key.pem -out user_certs/user_${CERT}_csr.pem -config openssl.cnf -utf8 -subj "/C=CN/ST=广东/L=gz/O=Home/CN=WiFi-${CERT}/" && \
openssl ca -days ${DAYS} -in user_certs/user_${CERT}_csr.pem -out user_certs/user_${CERT}_cert.pem -config openssl.cnf -extensions user_cert -batch && \
rm -rf user_certs/user_${CERT}_csr.pem && \
echo -e "Export certs...\n \"Export Password\" MUST set for IOS.\n \"Export Password\" MAY empty for Android,windows."  && \
openssl pkcs12 -export -out ./${exportdir}/${CERT}.p12 -inkey user_certs/user_${CERT}_key.pem -in user_certs/user_${CERT}_cert.pem -certfile ca_cert.pem -caname "Wifi EAP RootCA" -name "${CERT}-WiFi-User" -passout pass:${PASS}
# 友好名称 "-name" "-caname" windows中不支持utf8中文

echo ""
