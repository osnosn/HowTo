#!/bin/sh

#./new-ca.sh
# Create the master CA key and cert. This should be done once.
if [ -f ca_key.pem ]; then
	echo "Root CA key found. Exit."
	exit
fi
keytype=""
case "$1" in
   "rsa2048")
      keytype="rsa:2048"
      ;;
   "rsa4096")
      keytype="rsa:4096"
      ;;
   "ec256")
      keytype="ec:ec_param"
      openssl ecparam -name prime256v1 -out ec_param
      ;;
   "ec384")
      keytype="ec:ec_param"
      openssl ecparam -name secp384r1 -out ec_param
      ;;
   *)
      echo
      echo "Usage: $0  {rsa2048|rsa4096|ec256|ec384}"
      echo 
      exit
      ;;
esac

exportdir="4export"

echo "Self-sign the root CA..."
echo "No Root CA key found. Generating one"
openssl req -x509 -nodes -days 36500 -newkey ${keytype} -keyout ca_key.pem -out ca_cert.pem -new -sha512 -config openssl.cnf -extensions v3_ca -utf8 -subj "/C=CN/ST=广东/L=gz/O=Home/CN=Wifi EAP Root CA/"  && \
openssl x509 -outform der -in ca_cert.pem -out ./${exportdir}/CA.crt  && \
openssl x509 -in ca_cert.pem -noout -text > ca_cert.txt 
echo "You may now run ./new-server.sh"
echo ""
