#!/bin/sh

#./revoke-user.sh

CERT=$1
if [ $# -ne 1 ]; then
        echo "Usage: $0 userName"
        exit 1
fi
if [ ! -f user_certs/user_${CERT}_key.pem ]; then
	echo "user_certs/user_${CERT}_key.pem NOT found. Exit."
	exit 0
fi

openssl ca -revoke user_certs/user_${CERT}_cert.pem -config openssl.cnf && \
openssl ca -gencrl -keyfile ca_key.pem -cert ca_cert.pem -out crl.pem -config openssl.cnf && \
cat ca_cert.pem crl.pem > ca_cert+crl.pem
echo "You NEED update \"ca_cert_crl.pem\" file and restart service \"hostapd\"."


echo ""
