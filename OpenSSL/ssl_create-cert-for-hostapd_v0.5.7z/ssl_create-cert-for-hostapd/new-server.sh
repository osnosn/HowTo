#!/bin/sh

#./new-server.sh
# Create the server key.
if [ -f server_key.pem ]; then
	echo "Server key found. Exit."
	exit
fi
keytype=""
case "$1" in
   "rsa2048")
      keytype="rsa:2048"
      ;;
   "rsa4096")
      keytype="rsa:4096"
      ;;
   "ec256")
      keytype="ec:ec_param"
      openssl ecparam -name prime256v1 -out ec_param
      ;;
   "ec384")
      keytype="ec:ec_param"
      openssl ecparam -name secp384r1 -out ec_param
      ;;
   *)
      echo
      echo "Usage: $0  {rsa2048|rsa4096|ec256|ec384}"
      echo
      echo "   ECC or RSA are both OK. ECC 或 RSA 都可以。"
      echo
      echo "   When use ECC server cert, Android8 got \"no shared cipher\"."
      echo "   USE \"RSA\" cert on server side if use OLD android system."
      echo "   如果使用ECC证书，安卓8系统协商加密算法会失败。"
      echo "   如果用旧安卓系统，建议服务器证书使用\"RSA\"。"
      echo
      exit
      ;;
esac

echo "Create server ssl for hostapd."
echo "No Server key found. Generating one."

openssl req -nodes -new -newkey ${keytype} -keyout server_key.pem -out server_csr.pem -config openssl.cnf -utf8 -subj "/C=CN/ST=广东/L=gz/O=Home/CN=WiFi Radius Server/"  && \
openssl ca -days 36500 -in server_csr.pem -out server_cert.pem -config openssl.cnf -extensions server_cert -batch && \
rm -rf server_csr.pem
echo "You may now run ./create_crl.sh"
echo ""
